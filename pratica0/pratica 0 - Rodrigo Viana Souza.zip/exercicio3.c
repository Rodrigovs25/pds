#include <stdio.h>
#include <math.h>

int main(){
    float x, y;
    x = sin(3.14);
    y = sin(4.13);
    printf("\nSeno de 3,14 eh %f", x);
	printf("\nSeno de 4,13 eh %f", y);
}