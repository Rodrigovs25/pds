#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define TAM 100

int cubo(int n){
	if(n<=0)
		return 0;
	return pow(n, 3)+cubo(n-1);
}

void ordemcresecente(int n){
	if(n<0)
		return;
	ordemcresecente(n-1);
	printf("%d ", n);
}

void ordemdecresecente(int n){
	if(n<0)
		return;
	printf("%d ", n);
	ordemdecresecente(n-1);
}

int soma_vetor(int *v, int n){
	if(n-1 == 0)
		return v[n-1];
	else
		return v[n-1] + soma_vetor(v, n-1);
}

float media_vetor(int *v, int i, int n){
	if(i == n-1)
		return (float)v[i]/(float)n;
	else
		return (float)v[i] / (float)n + media_vetor(v, i+1, n);
}

int elevado(int x, int y){
	if(y==0)
		return 1;
	else
		return x * elevado(x, y-1);
}

void inversostr(char *s){
	if(*s == '\0')
		return;
	else{
		inversostr(s+1);
		printf("%c", *s);
		return;
	}
}

int inverteint(int n, int *soma){
	int resto;
	if(n==0)
		return *soma;
	else{
		resto = n%10;
		*soma *= 10;
		*soma += resto;
		inverteint(n/10, soma);
		return *soma;
	}
	
}

void basebinaria(int n){
	int bit;
	if(n<2){
		bit = n;
	}
	else if (n%2==0){
		basebinaria(n/2);
		bit = 0;
	}
	else{
		basebinaria(n/2);
		bit = 1;
	}
	printf("%d", bit);
}

int menor_vetor(int *v, int n){
	int vetor = v[n-1];
	int menor;
	if(n-1 == 0)
		return v[n-1];
	else{
		menor = menor_vetor(v, n-1);
		if(menor<=vetor){
			return menor;
		}
		else{
			return vetor;
		}
	}
}

int main(){
	
	int ninv=134;
	int a=1;
	int x=3, y=4;
	char *s1;
	int resultado=0;
	char s2[4] = "ola";
	int v1[1] = {4};
	int v2[2] = {3, 2};
	int v3[10] = {9, 8, 7, 6, 5, 4, 3, 2, 1, 0};
	
	//teste 1
	printf("\nCubo: %d", cubo(a));
	printf("\n");
	//teste 2
	ordemcresecente(a);
	printf("\n");
	//teste 3
	ordemdecresecente(a);
	printf("\n");
	//teste 4
	printf("\nSoma dos elementos do vetor: %d", soma_vetor(v1, 1));
	printf("\nSoma dos elementos do vetor: %d", soma_vetor(v2, 2));
	printf("\nSoma dos elementos do vetor: %d", soma_vetor(v3, 10));
	//teste 5
	printf("\nMedia dos elementos do vetor: %.2f", media_vetor(v1, 0, 1));
	printf("\nMedia dos elementos do vetor: %.2f", media_vetor(v2, 0, 2));
	printf("\nMedia dos elementos do vetor: %.2f", media_vetor(v3, 0, 10));
	//teste 6
	printf("\nO numero %d elevado a %d eh %d", x, y, elevado(x, y));
	//teste 7
	printf("\nString: 'Ola mundo', invetida: ");
	inversostr("Ola mundo");
	s1 = "mundo";
	printf("\nString: '%s, invetida: ", s1);
	inversostr(s1);
	printf("\nString: '%s, invetida: ", s2);
	inversostr(s2);
	//teste 8
	printf("\nNumero %d invertido eh %d", ninv, inverteint(ninv, &resultado));
	//teste 9
	printf("\nO numero %d em binario eh: ", 29);
	basebinaria(29);
	printf("\nO numero %d em binario eh: ", 0);
	basebinaria(0);
	printf("\nO numero %d em binario eh: ", 2);
	basebinaria(2);
	//teste 10
	printf("\nMenor dos elementos do vetor: %d", menor_vetor(v1, 1));
	printf("\nMenor dos elementos do vetor: %d", menor_vetor(v2, 2));
	printf("\nMenor dos elementos do vetor: %d", menor_vetor(v3, 10));
	
	
	
	return 0;
}